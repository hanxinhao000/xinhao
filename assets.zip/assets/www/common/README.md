#项目先关配置类的文件目录集合，如：
```
app.js
appConfig.js
ResourceManager.js
```